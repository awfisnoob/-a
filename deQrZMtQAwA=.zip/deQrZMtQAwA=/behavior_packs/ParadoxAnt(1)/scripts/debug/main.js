import './fakeplayer.js';
import './runcommand.js';
import './event.js';
import './tag.js';
import './dynamicproperties.js';
console.log('INIT!');
