import { world } from "mojang-minecraft";
import config from "../../data/config.js";
import { resetTag, getPrefix, crypto, sendMsgToPlayer, sendMsg } from "../../util.js";
const World = world;
function tagHelp(player, prefix, chatRanksBoolean) {
    let commandStatus;
    if (!config.customcommands.tag || !config.customcommands.chatranks) {
        commandStatus = "§6[§4DISABLED§6]§r";
    }
    else {
        commandStatus = "§6[§aENABLED§6]§r";
    }
    let moduleStatus;
    if (chatRanksBoolean === false || !config.customcommands.chatranks) {
        moduleStatus = "§6[§4DISABLED§6]§r";
    }
    else {
        moduleStatus = "§6[§aENABLED§6]§r";
    }
    return sendMsgToPlayer(player, [
        `\n§4[§6Command§4]§r: tag`,
        `§4[§6Status§4]§r: ${commandStatus}`,
        `§4[§6Module§4]§r: ${moduleStatus}`,
        `§4[§6Usage§4]§r: tag <username> [optional]`,
        `§4[§6Optional§4]§r: Rank:tag, Rank:tag--tag, reset, help`,
        `§4[§6Description§4]§r: Gives one or more ranks to a specified player or resets it.`,
        `§4[§6Examples§4]§r:`,
        `    ${prefix}tag ${player.name} Rank:Admin`,
        `    ${prefix}tag ${player.name} Rank:Contributor--Mod`,
        `    ${prefix}tag ${player.name} Rank:Staff--Mod--Helper`,
        `    ${prefix}tag help`,
    ]);
}
/**
 * @name tag
 * @param {BeforeChatEvent} message - Message object
 * @param {string[]} args - Additional arguments provided (optional).
 */
export function tag(message, args) {
    // validate that required params are defined
    if (!message) {
        return console.warn(`${new Date()} | ` + "Error: ${message} isnt defined. Did you forget to pass it? (./utility/tag.js:37)");
    }
    message.cancel = true;
    let player = message.sender;
    // fixes a bug that kills !tag when using custom names
    player.nameTag = player.name;
    // Check for hash/salt and validate password
    let hash = player.getDynamicProperty('hash');
    let salt = player.getDynamicProperty('salt');
    let encode;
    try {
        encode = crypto(salt, config.modules.encryption.password);
    }
    catch (error) { }
    // make sure the user has permissions to run the command
    if (hash === undefined || encode !== hash) {
        return sendMsgToPlayer(player, `§r§4[§6Paradox§4]§r You need to be Paradox-Opped to use this command.`);
    }
    // Get Dynamic Property Boolean
    let chatRanksBoolean = World.getDynamicProperty('chatranks_b');
    if (chatRanksBoolean === undefined) {
        chatRanksBoolean = config.modules.chatranks.enabled;
    }
    // Check for custom prefix
    let prefix = getPrefix(player);
    // Are there arguements
    if (!args.length) {
        return tagHelp(player, prefix, chatRanksBoolean);
    }
    // Was help requested
    let argCheck = args[0];
    if (argCheck && args[0].toLowerCase() === "help" || !config.customcommands.tag || !chatRanksBoolean || !config.customcommands.chatranks) {
        return tagHelp(player, prefix, chatRanksBoolean);
    }
    // try to find the player requested
    let member;
    for (let pl of World.getPlayers()) {
        if (pl.nameTag.toLowerCase().includes(args[0].toLowerCase().replace(/"|\\|@/g, ""))) {
            member = pl;
        }
    }
    if (!member) {
        return sendMsgToPlayer(player, `§r§4[§6Paradox§4]§r Couldnt find that player!`);
    }
    // check if array contains the string 'reset'
    let argcheck = args.includes('reset');
    // reset rank
    if (argcheck === true) {
        resetTag(player, member);
        // tagRank(member);
        return;
    }
    let custom;
    args.forEach(t => {
        if (t.startsWith('Rank:')) {
            custom = t;
        }
    });
    if (custom.startsWith('Rank:')) {
        resetTag(player, member);
        member.addTag(`${custom}`);
        // tagRank(member);
    }
    else {
        return tagHelp(player, prefix, chatRanksBoolean);
    }
    if (player === member) {
        return sendMsg('@a[tag=paradoxOpped]', `${player.nameTag} has changed their rank`);
    }
    sendMsg('@a[tag=paradoxOpped]', `${player.nameTag} has changed ${member.nameTag}'s rank!`);
}
