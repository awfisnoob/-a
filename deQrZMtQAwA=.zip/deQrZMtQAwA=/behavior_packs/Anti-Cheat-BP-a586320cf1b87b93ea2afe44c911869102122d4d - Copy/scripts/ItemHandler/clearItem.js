import { system, world, Container } from "@minecraft/server";

const bannedItems = [
  "minecraft:bee_nest",
  "minecraft:beehive",
  "minecraft:moving_block",
  "minecraft:movingblock",
  "minecraft:movingBlock"
];

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    /**
     * @type {Container}
     */
    const container = player.getComponent("inventory").container;

    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (!item || !bannedItems.includes(item.typeId)) continue;
      container.setItem(i);
      world.sendMessage(
        `${player.name} 被發現擁有非法物品. ${item.typeId} 被清除.`
      );
    }
  }
});